### CubicSun * Bot Oficial

Atualmente a comunidade possui dois mil membros, no qual eu estou desde o inicio, e fico feliz de estar apoiando a tanto tempo. Esse bot foi feito desde 02/2020, vai fazer um ano que eu trabalho na Cubic. E fico feliz de ter chegado tão longe, sem eles eu não seria nada. Sou muito grato a todos que me apoiaram, especialmente o DARKNESS, que sempre gostou do meu trabalho e me fez continuar até o final.

### Comandos

O bot teve varios comandos que foram retirados, e outros adicionados sendo que ninguem conhece. Vou tentar melhorar os comandos daqui pra frente, meu nivel como desenvolvedor melhorou muito. E estou disposto a me esforçar pela comunidade assim como fazia nos velhos tempos.

### Projetos

Estou planejando o site, api, e o aplicativo da Cubic. Assim facilitando todo o serviço para mantermos a nossa comunidade ativa.

### Finalização

O bot da cubic tem mais de 7 meses brutos trabalho em cima dele, sou muito grato de ver nele o que eu passei na minha vida de programador. Atualmente possuimos 30 comandos, alguns com bugs, outros não... Sempre tentando deixar o bot o mais perfeito possivel para todos os usuários que permanecem em nossa comunidade usufruir dos comandos do mesmo. Bom, eu me chamo Gabriel e esse foi um dos meus primeiros bots.