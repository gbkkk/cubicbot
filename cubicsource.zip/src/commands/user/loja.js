const Discord = require('discord.js')

module.exports = {
    name: 'loja',
    aliases: ['loja', 'shop'],
    run: async (client, message, args, database) => {
    
        var emotes = ["813562954992975914", "813562955115135017", "813562955375181824", "813562955613470720", "813562955735367690", "813562957517946910", "813562957229064243", "813562957136658455", "813562957773537350", "813562956918423562"]
       
        var embed = {
            title: ':moneybag: ⋅ Seja bem vindo a loja de beneficios',
            description: `Seja bem vindo a nossa loja, aqui você pode comprar beneficios com **pontos.**\n\n<:1_:813562954992975914> `,
            color: 'YELLOW'
        }

    }
}